<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_order_info`;");
E_C("CREATE TABLE `ecs_order_info` (
  `order_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(20) NOT NULL DEFAULT '',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `consignee` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) unsigned NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL DEFAULT '0',
  `city` smallint(5) unsigned NOT NULL DEFAULT '0',
  `district` smallint(5) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `best_time` varchar(120) NOT NULL DEFAULT '',
  `sign_building` varchar(120) NOT NULL DEFAULT '',
  `postscript` varchar(255) NOT NULL DEFAULT '',
  `shipping_id` tinyint(3) NOT NULL DEFAULT '0',
  `shipping_name` varchar(120) NOT NULL DEFAULT '',
  `pay_id` tinyint(3) NOT NULL DEFAULT '0',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `defaultbank` varchar(20) NOT NULL COMMENT '银行',
  `how_oos` varchar(120) NOT NULL DEFAULT '',
  `how_surplus` varchar(120) NOT NULL DEFAULT '',
  `pack_name` varchar(120) NOT NULL DEFAULT '',
  `card_name` varchar(120) NOT NULL DEFAULT '',
  `card_message` varchar(255) NOT NULL DEFAULT '',
  `inv_payee` varchar(120) NOT NULL DEFAULT '',
  `inv_content` varchar(120) NOT NULL DEFAULT '',
  `goods_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `shipping_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `insure_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pay_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pack_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `card_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `money_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `surplus` decimal(10,2) NOT NULL DEFAULT '0.00',
  `integral` int(10) unsigned NOT NULL DEFAULT '0',
  `integral_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bonus` decimal(10,2) NOT NULL DEFAULT '0.00',
  `order_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `from_ad` smallint(5) NOT NULL DEFAULT '0',
  `referer` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `confirm_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `shipping_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pack_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `card_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bonus_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `invoice_no` varchar(255) NOT NULL DEFAULT '',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `extension_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `to_buyer` varchar(255) NOT NULL DEFAULT '',
  `pay_note` varchar(255) NOT NULL DEFAULT '',
  `agency_id` smallint(5) unsigned NOT NULL,
  `inv_type` varchar(60) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `is_separate` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `discount` decimal(10,2) NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `rebate_id` int(10) unsigned NOT NULL DEFAULT '0',
  `rebate_ispay` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '是否订单已经返佣(2:已返,1:未返)',
  `tb_nick` varchar(50) NOT NULL COMMENT '淘宝昵称',
  `froms` char(10) NOT NULL DEFAULT 'pc' COMMENT 'pc:电脑,mobile:手机,app:应用',
  `is_pickup` tinyint(1) NOT NULL,
  `pickup_point` int(11) NOT NULL,
  `vat_inv_company_name` varchar(60) DEFAULT NULL COMMENT '增值税发票单位名称',
  `vat_inv_taxpayer_id` varchar(20) DEFAULT NULL COMMENT '增值税发票纳税人识别号',
  `vat_inv_registration_address` varchar(120) DEFAULT NULL COMMENT '增值税发票注册地址',
  `vat_inv_registration_phone` varchar(60) DEFAULT NULL COMMENT '增值税发票注册电话',
  `vat_inv_deposit_bank` varchar(120) DEFAULT NULL COMMENT '增值税发票开户银行',
  `vat_inv_bank_account` varchar(30) DEFAULT NULL COMMENT '增值税发票银行账户',
  `inv_consignee_name` varchar(60) DEFAULT NULL COMMENT '收票人姓名',
  `inv_consignee_phone` varchar(60) DEFAULT NULL COMMENT '收票人手机',
  `inv_consignee_country` smallint(5) DEFAULT '1' COMMENT '收票人国家',
  `inv_consignee_province` smallint(5) DEFAULT NULL COMMENT '收票人省',
  `inv_consignee_city` smallint(5) DEFAULT NULL COMMENT '收票人市',
  `inv_consignee_district` smallint(5) DEFAULT NULL COMMENT '收票人县/区',
  `inv_consignee_address` varchar(120) DEFAULT NULL COMMENT '收票人详细地址',
  `inv_status` varchar(20) NOT NULL DEFAULT 'unprovided ' COMMENT '发票出票状态',
  `inv_remark` text COMMENT '发票备注',
  `inv_money` decimal(10,2) DEFAULT '0.00' COMMENT '发票金额',
  `inv_payee_type` varchar(20) DEFAULT NULL COMMENT '发票抬头类型',
  `shipping_time_end` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`),
  KEY `order_status` (`order_status`),
  KEY `shipping_status` (`shipping_status`),
  KEY `pay_status` (`pay_status`),
  KEY `shipping_id` (`shipping_id`),
  KEY `pay_id` (`pay_id`),
  KEY `extension_code` (`extension_code`,`extension_id`),
  KEY `agency_id` (`agency_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `rebate` (`rebate_id`,`rebate_ispay`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_order_info` values('1','2015102881832','10','0','0','0','家里冷','1','4','54','534','家里冷','','9855','13999999999','xjtong@qq.com','送货时间不限','','','2','门店自提','7','微信支付','','等待所有商品备齐后再发','','','','','','','4699.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','4699.00','0','网站自营','1445997352','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','0','0','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'4699.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('5','2015102803948','10','0','0','0','家里冷','1','4','54','534','家里冷','','9855','13999999999','xjtong@qq.com','仅工作日送货','','','4','申通快递','6','货到付款','','等待所有商品备齐后再发','','','','','','','120.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','135.00','0','网站自营','1446001806','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','0','0','1','','pc','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'135.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('3','2015102839739','10','0','0','0','dsfdsad','1','2','52','500','dsfsd ','','--','13333333333','','送货时间不限','','','3','顺丰速运','7','银行汇款/转帐','','等待所有商品备齐后再发','','','','','','','299.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','314.00','0','L&amp;L','1446001714','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','5','2','3','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'314.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('4','2015102880040','10','0','0','0','dsfdsad','1','2','52','500','dsfsd ','','--','13333333333','','送货时间不限','','','3','顺丰速运','7','银行汇款/转帐','','等待所有商品备齐后再发','','','','','','','199.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','214.00','0','网站自营','1446001715','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','2','0','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'214.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('6','2015102830995','10','0','0','0','dsfdsad','1','2','52','500','dsfsd ','','--','13333333333','','送货时间不限','','','2','门店自提','8','微信支付','','等待所有商品备齐后再发','','','','','','','199.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','199.00','0','网站自营','1446001910','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','0','0','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'199.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('7','2015102990548','13','0','0','0','111','1','2','52','501','11111','','--','13898754584','','送货时间不限','','','3','顺丰速运','9','环迅IPS','','等待所有商品备齐后再发','','','','','','','2999.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','3014.00','0','网站自营','1446073808','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','0','0','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'3014.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('8','2015102900411','10','0','0','0','dsfdsad','1','2','52','500','dsfsd ','','--','13333333333','','送货时间不限','','','3','顺丰速运','8','微信支付','','等待所有商品备齐后再发','','','','','','','2098.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','2113.00','0','金星家纺','1446081964','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','7','0','4','1','','mobile','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'2113.00',NULL,'0');");
E_D("replace into `ecs_order_info` values('9','2015103020579','17','0','0','0','111','1','3','37','410','模压土土魂牵梦萦 ','','--','13822319077','132136545@qq.com','工作日/周末/假日均可','','','3','顺丰速运','1','支付宝','','等待所有商品备齐后再发','','','','','','','320.00','15.00','0.00','0.00','0.00','0.00','0.00','0.00','0','0.00','0.00','335.00','8','网站自营','1446155132','0','0','0','0','0','0','','','0','','','0','','0.00','0','0','0.00','0','0','0','1','','pc','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'unprovided ',NULL,'335.00',NULL,'0');");

require("../../inc/footer.php");
?>