<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sessions`;");
E_C("CREATE TABLE `ecs_sessions` (
  `sesskey` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `expiry` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `user_name` varchar(60) NOT NULL,
  `user_rank` tinyint(3) NOT NULL,
  `discount` decimal(3,2) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sessions` values('491549939b0279d8cddc8496547f3645','1446187586','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('97845f37b5f14d73292aba76156b8d12','1446187491','0','0','61.151.186.146','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4fbc505763375c1afb95457ac013a812','1446187059','0','0','123.125.71.33','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ed1265345a3f8509b9d96a608c25fbf5','1446187256','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d8e50d6d8279cede53a42158f26659e4','1446186618','0','0','123.125.71.115','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('773ad8b24b70ad99131cf731232cc005','1446186395','0','0','220.181.108.177','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('bd7cd28a0d18dff5497576d4682588bf','1446186259','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('40774ce27056fb96845c1f60eedad9c3','1446186314','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('141da40126448d49f56424bc00ea12da','1446187391','0','0','183.61.236.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b70e67580bcd248ca47f65a79c93b08c','1446186749','0','0','117.27.149.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('e37837ae3af03052656f57977c63afd3','1446186284','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7902ebcad9265ea45919dac4bfa14e87','1446187306','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fdecf0b8875bd29dda51143d4e43dd13','1446186749','0','0','117.27.149.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f989b3c01a5833f300b658a4e431290e','1446186295','0','0','180.76.15.11','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b959d1434f74d9fae05de5ce341e34cf','1446186720','0','0','14.17.29.85','0','0','0.00','0','a:0:{}');");
E_D("replace into `ecs_sessions` values('f79d1317d26fd1751b78e37785b7481e','1446187246','0','0','112.117.216.171','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('806b6dfc81fb161bafabb12677e5b6ed','1446186590','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('92aae8ee9947f74beab3d835f0cef7c4','1446186613','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('cea8b01fa1ba8f6a10abca71a4918262','1446186274','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7153fd2c3c5fe4f7bc7804b6c749fda9','1446186603','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('92af8f18610bcb1f4df44f207169c849','1446186290','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('366b6af012899f4cf4d06ecd4d271b0c','1446186601','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('da0866d62f20617d5927587c8ddd4d24','1446186598','0','0','175.22.3.40','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('887313b7b96522e29261e35a7919da83','1446186582','0','0','61.55.172.157','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('feedf1943787a8f0d9081aec0213fa0b','1446187403','0','0','117.34.28.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('335b429af75f19b6079db06262efd53a','1446186557','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7bcab0302808e130056b31c8a6ead317','1446186415','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b2916f600b8e46356af80df0645012dd','1446186268','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b6573718158dd8103ffe0bb9ddbb12c2','1446186263','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('526fff5871f04070acf56c91b5fb3f32','1446187383','0','4','106.42.174.30','0','0','0.00','0','');");
E_D("replace into `ecs_sessions` values('728adc8ea787758ff3938fad7d5d4113','1446186782','0','0','183.60.235.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('a58ccfe247f484c6e42bc646900311a1','1446186470','0','0','99.226.110.61','0','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"OWQ4Njc1ZTA1NA==\";}');");
E_D("replace into `ecs_sessions` values('cc3e6c38f7baadb59ec4f321179da978','1446186368','0','0','117.27.149.13','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('6808550484f25fab8be6b98e5b72d98c','1446186447','0','0','101.226.33.200','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('bf96e8fd80998bf4f2b9b0e01a35f4f1','1446186457','0','0','183.60.235.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('686175364de47623f371b2c554f05619','1446186781','0','0','183.60.235.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('5735756c40e979a45ef5a9ef2c296990','1446186457','0','0','183.60.235.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('441e535ffc4bd10a7561c0d75e00dcdf','1446186779','0','0','180.76.15.11','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('3a42569c1808acb7dd272d42ee939867','1446186267','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('1e57c950c3c1b9d13354dd8424756727','1446187211','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('922c0bbaf25e4c342c668a065e257db7','1446186261','0','0','112.117.216.171','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('775cbe622276b35f85f7406d8a1bad84','1446186551','0','0','171.111.154.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ab0b200dfd401a8ebadd8e5b27ad651a','1446186450','0','0','99.226.110.61','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('dc27030e5c5d4ab04a30daef4ddedb39','1446186449','0','0','99.226.110.61','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('69abd9f5cb66f17b5b5422881b832d05','1446187244','0','0','61.55.172.157','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('98e90e3e87d10388849951084e595111','1446187218','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('c1adc30525f5af88f36001dfc9f42c15','1446187404','0','0','117.34.28.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('abdac66bf711a42325a61c38d70fce3e','1446186594','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('5bacdc391e09ff86ace65cef2452e712','1446187766','0','0','36.99.30.144','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ce73778f8cd4020b6a35802e7392e6a9','1446186406','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('941ded612c8373d528b2365408a02292','1446187329','0','0','106.42.174.30','0','0','1.00','0','a:5:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"NzM3NGU5Y2VjYw==\";s:9:\"flow_type\";i:0;}');");
E_D("replace into `ecs_sessions` values('6e9e687b6429909e8cebcb80a26b7263','1446186587','0','0','112.117.216.171','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f889dda8fa19e8def603f376d8a16650','1446187262','0','0','175.22.3.40','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('a785a3d12b472846b44e1dc61c91d793','1446186259','0','0','61.55.172.157','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('046815197b3c93548ba5856a967652f5','1446186541','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('859a3825627c82eec63cebc23c9b0a37','1446187253','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d6f665bd8963d9fed2ef5282d84bc86e','1446186341','0','0','180.76.15.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('3e8366de8af71369c770a65ed9195266','1446187162','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('61490084cdb6ebc3030fb8031caef2c6','1446186325','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('21c149b5c2b3788bdeb47aac53dbc844','1446187262','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('97f7a90871471bafc42be1e31cd45cb9','1446186978','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('462ad437d3949a38e3d22dea494c4707','1446186446','0','0','99.226.110.61','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('53004410ec41d9bf8e7ab3d718c2cb87','1446187023','0','0','113.12.133.184','0','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"MzBhODQ4MDk1ZQ==\";}');");
E_D("replace into `ecs_sessions` values('b438bcd31606c3ca0a14c025979d8a00','1446186217','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4a08c0fb42bc560120c7bc73b5b607c4','1446186282','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ad5d4a3b5325e25b17cc4312b19c98e3','1446187489','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('752c0cb0d4d2b22b6d3bd088cc2dd126','1446186494','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f20ec8963bc79db1d6f849130186182c','1446187462','0','0','171.13.14.233','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('78e49c6aedb6f0730a6a65569e3c7ab5','1446186947','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4905a9d3a23bb2e1d9b1971d2ceb1df7','1446186937','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('99f2a47166c24c7c6f84627e3909bdfe','1446186425','0','0','220.181.108.82','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f27f535ade7378c6de03aa91addfad34','1446186779','0','0','180.76.15.12','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('42f7fe9b2fb0c955634315fabf0bd34d','1446186277','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('536729581362d39764a04b40ab42553c','1446187602','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('279a06d20c2144e829f8d3b39bec43a3','1446187612','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4ac1b870ab0bdd628c572151d6528975','1446187399','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('54a453060a5de9231d3f58d21b7985f9','1446186740','0','0','117.34.28.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b695dfe5673733a5d2fc533045322396','1446187596','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7549a0ab98401d795f137834c6fe0f10','1446186921','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9ab871885f73a3390092aa7bf4d0b065','1446186740','0','0','117.34.28.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('e6a9420591d827623910023a974d37ed','1446186846','0','0','123.125.71.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ec0a336923be9a3a6103f49b5d55842b','1446186735','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('8b3ca74f53b4442f2bdada2cedf2c8bb','1446187601','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('610ebbd07ef5a7a50d4eea39ca82adf7','1446187589','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4d0ad332ce9d806cdbe9158ebab797bb','1446187490','0','0','61.151.186.146','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7a086e0da21533327e9bd3198037fd30','1446187466','0','0','171.13.14.233','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b518223e57272f01a72dca89dc572b16','1446186734','0','0','183.61.236.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4a1b446e9c3a0f797b1c4a5a6560ba61','1446187452','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('11b196b72751bb09e82e78248f42ee87','1446186172','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('bad4d12e38819bbe43fe3aca94548b2b','1446186434','0','0','117.27.149.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('c469fb294d2c755bc120d19c6dc137e7','1446187398','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('480634c01a15dae9cbad78d595f68420','1446186069','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('5ee858b3d951318d1dbdd817e0bc5f8e','1446187439','0','0','183.60.235.17','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('8fd6ed67e1e98b0527f492fc1809685c','1446185993','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fd2a42864c80da1b9a2b9d27df0c7d6f','1446187821','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('0b30c31f71b43bbf437cc4f2d135849e','1446186736','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('47c8aa028aae5f56d7aa2ef9eee558bd','1446187515','0','0','222.245.229.116','0','0','0.00','0','');");
E_D("replace into `ecs_sessions` values('f982258482a026e0c325f7464ebe4527','1446187393','0','0','183.61.236.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('684a05edf4bb37b510aa28f2b2072df0','1446187155','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('c54473c733fb6265ef5d23ad16d11c3a','1446187438','0','0','183.60.235.17','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('6f701576b4d8cc0e90d7c4c37403212f','1446187406','0','0','117.27.149.13','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7d29204faed4aa085ac892b3a21c53db','1446187406','0','0','117.27.149.13','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7dff5d83c59c31c58751d62d44e2c2f4','1446187331','0','0','111.206.61.180','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('e58bfe3fde9d41ceef2acc8a316dfb1c','1446186417','0','0','117.34.28.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('af1ff263583cc49d7330c03902f5aee1','1446187767','0','0','36.99.30.144','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('afdcba3ea0f4e12b99ae1246dd3b847f','1446187213','0','0','171.111.154.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b470cf1739d45b99ef2c3068d3ae7bfb','1446187190','0','0','220.243.139.60','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f2f07200c71bc029a6aeff9075dea7f3','1446186445','0','0','101.226.33.200','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d1ebd3c00e24c6ccdb44332243a1afd1','1446186435','0','0','117.27.149.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('89d0e1cc4b93170e2fcb39b21916ae93','1446186417','0','0','117.34.28.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('1b841d4f92c8d683f899c3d5f5b01a7c','1446186930','0','0','180.153.229.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fb3b5bd28a826f4b42dd6850a501b108','1446186275','0','0','175.22.3.40','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('a742e08a73551ecae177e0e0c7f131e8','1446186734','0','0','183.61.236.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('31b8d8c1ec11c1fe3b6e5c68032fbcf5','1446186824','0','0','125.88.219.96','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9568c7a4de8f7d07633f3139bc7aa6ff','1446186538','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('c3bcc909e5d70b91126b2354a06a5c71','1446186410','0','0','183.61.236.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9f6af2b2c41907b93d09acf4b4e0f0de','1446186410','0','0','183.61.236.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('df091df1b7718d6fbb53618672a3d359','1446186416','0','0','119.167.246.15','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('1863ffff5b6848fb8eff0d72ad02fefc','1446186246','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('1fce82698c7911eeea8584fd0f0cdb21','1446186996','0','0','188.165.15.117','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('8ceae69293b81236918ec2e09b915ae0','1446186230','0','0','171.111.154.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");

require("../../inc/footer.php");
?>