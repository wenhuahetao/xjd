<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_order_goods`;");
E_C("CREATE TABLE `ecs_order_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_name` varchar(120) NOT NULL DEFAULT '',
  `goods_sn` varchar(60) NOT NULL DEFAULT '',
  `product_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_number` smallint(5) unsigned NOT NULL DEFAULT '1',
  `market_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `goods_attr` text NOT NULL,
  `send_number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_real` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `is_gift` smallint(5) unsigned NOT NULL DEFAULT '0',
  `goods_attr_id` varchar(255) NOT NULL DEFAULT '',
  `comment_state` tinyint(1) NOT NULL DEFAULT '0',
  `shaidan_state` tinyint(1) NOT NULL DEFAULT '0',
  `package_attr_id` varchar(100) NOT NULL,
  `is_back` tinyint(1) NOT NULL DEFAULT '0',
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `promote_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`rec_id`),
  KEY `order_id` (`order_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_order_goods` values('1','1','175','摩托罗拉 moto x pro(XT1115) 64GB 雅典黑 移动联通电信4G手机','ECS000175','0','1','4799.00','4699.00','','0','1','','0','0','','0','0','','0','0.00','0.00');");
E_D("replace into `ecs_order_goods` values('2','3','34','夏装甜美爱心提花蕾丝连衣裙女 宽松欧根纱背心裙','ECS000034','5','1','441.59','299.00','颜色:米色 \n尺码:S \n','0','1','','0','0','8,10','0','0','','0','0.00','0.00');");
E_D("replace into `ecs_order_goods` values('3','4','206','洛斐（Lofree）创意无线蓝牙音箱音响 电脑音箱 EDGE锋芒3C建筑美学','ECS000206','0','1','290.00','199.00','','0','1','','0','0','','0','0','','0','0.00','199.00');");
E_D("replace into `ecs_order_goods` values('4','5','28','进口费列罗巧克力礼盒DIY心形27粒【顺丰包邮】【代写贺卡】七夕礼物生日创意礼品','ECS000028','0','1','144.00','120.00','','0','1','','0','0','','0','0','','0','0.00','0.00');");
E_D("replace into `ecs_order_goods` values('5','6','206','洛斐（Lofree）创意无线蓝牙音箱音响 电脑音箱 EDGE锋芒3C建筑美学','ECS000206','0','1','290.00','199.00','','0','1','','0','0','','0','0','','0','0.00','199.00');");
E_D("replace into `ecs_order_goods` values('6','7','223','乐和居 双人床 床 榻榻米床 头层真皮','ECS000223','0','1','3598.79','2999.00','','0','1','','0','0','','0','0','','0','0.00','0.00');");
E_D("replace into `ecs_order_goods` values('7','8','120','柏年好禾 家具 欧式床 真皮实木床 法式田园公主床','ECS000120','0','1','2517.60','2098.00','','0','1','','0','0','','0','0','','0','0.00','0.00');");
E_D("replace into `ecs_order_goods` values('8','9','29','意大利费列罗巧克力食品进口零食礼盒576粒整箱装结婚喜糖','ECS000029','0','1','456.00','320.00','','0','1','','0','0','','0','0','','0','0.00','0.00');");

require("../../inc/footer.php");
?>