<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_email_sendlist`;");
E_C("CREATE TABLE `ecs_email_sendlist` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `template_id` mediumint(8) NOT NULL,
  `email_content` text NOT NULL,
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `pri` tinyint(10) NOT NULL,
  `last_send` int(10) NOT NULL,
  `supplier_id` mediumint(8) NOT NULL DEFAULT '0' COMMENT '店铺id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_email_sendlist` values('1','anan@68ecshop.com','6','亲爱的anan您好！\n\n恭喜您获得了1个红包，金额为10.00\n68ecshop2015-07-23','0','1','1437615423','0');");
E_D("replace into `ecs_email_sendlist` values('2','285188787@qq.com','6','亲爱的68ecshopyy您好！\n\n恭喜您获得了1个红包，金额为10.00\n68ecshop2015-07-23','0','1','1437615423','0');");
E_D("replace into `ecs_email_sendlist` values('3','3490134@qq.com','6','亲爱的yiren您好！\n\n恭喜您获得了1个红包，金额为10.00\n68ecshop2015-07-23','0','1','1437615423','0');");
E_D("replace into `ecs_email_sendlist` values('4','anan@68ecshop.com','6','亲爱的68ecshop您好！\n\n恭喜您获得了1个红包，金额为10.00\n68ecshop2015-08-21','0','1','1440143952','0');");
E_D("replace into `ecs_email_sendlist` values('5','285188787@qq.com','6','亲爱的68ecshopyy您好！\n\n恭喜您获得了1个红包，金额为10.00\n68ecshop2015-08-21','0','1','1440143952','0');");
E_D("replace into `ecs_email_sendlist` values('6','anan@68ecshop.com','6','亲爱的anan您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('7','285188787@qq.com','6','亲爱的68ecshopyy您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('8','admin9@qq.com','6','亲爱的admin9您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('9','admin8@qq.com','6','亲爱的admin8您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('10','2691111111@qq.com','6','亲爱的leilei您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('11','3490134@qq.com','6','亲爱的yiren您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('12','33342@qq.com','6','亲爱的liuyu您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('13','222222@qq.com','6','亲爱的liza您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('14','admin123@qq.com','6','亲爱的admin123您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('15','xjtong@qq.com','6','亲爱的u811KZYQ4976您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180985','10');");
E_D("replace into `ecs_email_sendlist` values('16','884501705@qq.com','6','亲爱的u411PPLM9325您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");
E_D("replace into `ecs_email_sendlist` values('17','17780945@qq.com','6','亲爱的u171CPVW8347您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");
E_D("replace into `ecs_email_sendlist` values('18','12@qq.com','6','亲爱的u915YXZN1536您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");
E_D("replace into `ecs_email_sendlist` values('19','695105738@qq.com','6','亲爱的jim5842您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");
E_D("replace into `ecs_email_sendlist` values('20','200508318@qq.com','6','亲爱的u183HGCQ3501您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");
E_D("replace into `ecs_email_sendlist` values('21','jingbiaoluo@vip.163.com','6','亲爱的u735MRML5358您好！\n\n恭喜您获得了1个红包，金额为89.00\n商家店铺名称2015-10-30','0','1','1446180989','10');");

require("../../inc/footer.php");
?>