<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_user_bonus`;");
E_C("CREATE TABLE `ecs_user_bonus` (
  `bonus_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bonus_type_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bonus_sn` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `used_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `emailed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `supplier_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '店铺id',
  PRIMARY KEY (`bonus_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_user_bonus` values('1','2','0','1','1446155132','9','1','0');");
E_D("replace into `ecs_user_bonus` values('2','2','0','2','1437780225','142','1','0');");
E_D("replace into `ecs_user_bonus` values('3','2','0','6','0','0','1','0');");
E_D("replace into `ecs_user_bonus` values('5','2','0','1','0','0','1','0');");
E_D("replace into `ecs_user_bonus` values('6','2','0','2','0','0','1','0');");
E_D("replace into `ecs_user_bonus` values('7','2','1000003386','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('8','2','1000012392','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('9','2','1000022118','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('10','2','1000039578','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('11','2','1000043598','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('12','2','1000058827','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('13','2','1000068065','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('14','2','1000072878','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('15','2','1000082971','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('16','2','1000098825','0','0','0','0','0');");
E_D("replace into `ecs_user_bonus` values('17','5','0','1','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('18','5','0','2','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('19','5','0','3','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('20','5','0','4','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('21','5','0','5','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('22','5','0','6','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('23','5','0','7','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('24','5','0','8','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('25','5','0','9','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('26','5','0','10','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('27','5','0','11','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('28','5','0','12','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('29','5','0','13','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('30','5','0','14','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('31','5','0','15','0','0','1','10');");
E_D("replace into `ecs_user_bonus` values('32','5','0','16','0','0','1','10');");

require("../../inc/footer.php");
?>