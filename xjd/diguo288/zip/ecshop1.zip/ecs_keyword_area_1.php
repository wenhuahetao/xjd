<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_keyword_area`;");
E_C("CREATE TABLE `ecs_keyword_area` (
  `access_time` int(10) unsigned NOT NULL DEFAULT '0',
  `w_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  `area` varchar(30) NOT NULL DEFAULT '',
  KEY `access_time` (`access_time`),
  KEY `w_id` (`w_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_keyword_area` values('1437586690','1','192.168.1.189','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688030','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688204','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688209','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1440115188','3','192.168.1.152','LAN');");
E_D("replace into `ecs_keyword_area` values('1440115201','4','192.168.1.152','LAN');");
E_D("replace into `ecs_keyword_area` values('1445416501','5','66.249.64.5','');");
E_D("replace into `ecs_keyword_area` values('1445973318','5','66.249.64.237','');");
E_D("replace into `ecs_keyword_area` values('1445974849','6','66.249.64.5','');");
E_D("replace into `ecs_keyword_area` values('1445983322','5','66.249.64.125','');");
E_D("replace into `ecs_keyword_area` values('1445986367','5','66.249.64.5','');");
E_D("replace into `ecs_keyword_area` values('1445986371','5','66.249.64.120','');");
E_D("replace into `ecs_keyword_area` values('1445986375','5','66.249.64.125','');");
E_D("replace into `ecs_keyword_area` values('1446009802','5','171.213.126.171','');");
E_D("replace into `ecs_keyword_area` values('1446022796','5','66.249.79.229','');");
E_D("replace into `ecs_keyword_area` values('1446037805','5','66.249.79.243','');");
E_D("replace into `ecs_keyword_area` values('1446038329','5','66.249.79.243','');");
E_D("replace into `ecs_keyword_area` values('1446045606','5','66.249.79.243','');");
E_D("replace into `ecs_keyword_area` values('1446065757','7','171.215.46.123','');");
E_D("replace into `ecs_keyword_area` values('1446071387','5','66.249.79.229','');");
E_D("replace into `ecs_keyword_area` values('1446075050','7','171.11.103.132','');");
E_D("replace into `ecs_keyword_area` values('1446075240','7','171.11.103.132','');");
E_D("replace into `ecs_keyword_area` values('1446081343','5','66.249.79.236','');");

require("../../inc/footer.php");
?>